package com.github.mayconr.juoforge.reader.map;

public record MapTile(
        int id,
        int x,
        int y,
        byte z
) {
}
