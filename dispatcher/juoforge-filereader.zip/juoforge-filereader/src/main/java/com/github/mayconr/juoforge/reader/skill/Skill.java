package com.github.mayconr.juoforge.reader.skill;

public record Skill(
        int index,
        String name,
        boolean hasAction
) {
}
