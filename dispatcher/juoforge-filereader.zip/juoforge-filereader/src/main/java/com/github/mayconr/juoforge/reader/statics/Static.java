package com.github.mayconr.juoforge.reader.statics;

public record Static(
        int id,
        int x,
        int y,
        byte z,
        int hue
) {
}
