package com.github.mayconr.juoforge.reader.tiledata;

import java.util.Set;

public record StaticTile(
        Set<TileFlag> flags,
        int weight,
        int layer,
        int count,
        int animId,
        int hue,
        int lightIndex,
        int height,
        String name
) { }
