package com.github.mayconr.juoforge.reader.tiledata;

import java.util.EnumSet;
import java.util.Set;

public enum TileFlag {

    BACKGROUND(0x00000001L),
    WEAPON(0x00000002L),
    TRANSPARENT(0x00000004L),
    TRANSLUCENT(0x00000008L),
    WALL(0x00000010L),
    DAMAGING(0x00000020L),
    IMPASSABLE(0x00000040L),
    WET(0x00000080L),
    SURFACE(0x00000200L),
    BRIDGE(0x00000400L),
    WINDOW(0x00001000L),
    NO_SHOOT(0x00002000L),
    FOLIAGE(0x00020000L),
    PARTIAL_HUE(0x00040000L),
    CONTAINER(0x00200000L),
    WEARABLE(0x00400000L),
    LIGHT_SOURCE(0x00800000L),
    ANIMATION(0x01000000L),
    ROOF(0x10000000L),
    DOOR(0x20000000L);

    private final long mask;

    TileFlag(long mask) {
        this.mask = mask;
    }

    public long mask() {
        return mask;
    }

    public boolean isSet(long flags) {
        return (flags & mask) != 0;
    }

    public static Set<TileFlag> from(long flags) {

        EnumSet<TileFlag> result = EnumSet.noneOf(TileFlag.class);

        for (TileFlag flag : values()) {
            if (flag.isSet(flags)) {
                result.add(flag);
            }
        }

        return result;
    }
}
