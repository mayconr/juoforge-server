package com.github.mayconr.juoforge.reader.view;

import com.github.mayconr.juoforge.reader.skill.Skill;

import java.util.List;
import java.util.Optional;

public interface GameDataProvider {

    LandTile tileAt(int x, int y);

    List<StaticTile> staticsAt(int x, int y);

    Optional<Skill> skillBy(int skillId);

}
