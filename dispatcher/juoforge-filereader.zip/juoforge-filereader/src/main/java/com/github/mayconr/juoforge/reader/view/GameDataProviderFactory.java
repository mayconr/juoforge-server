package com.github.mayconr.juoforge.reader.view;

import com.github.mayconr.juoforge.reader.map.MapReader;
import com.github.mayconr.juoforge.reader.skill.SkillsReader;
import com.github.mayconr.juoforge.reader.statics.StaticsReader;
import com.github.mayconr.juoforge.reader.tiledata.TileDataReader;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Path;

public class GameDataProviderFactory {

    public static GameDataProvider create(Path root, boolean highSea) {
        try (
                MapReader mapReader = MapReader.load(root.resolve("map0.mul"));
                StaticsReader staticReader = StaticsReader.load(root.resolve("statics0.mul"), root.resolve("staidx0.mul"));
                TileDataReader tileData = TileDataReader.load(root.resolve("tiledata.mul"), !highSea);
                SkillsReader skillsReader = SkillsReader.load(root.resolve("skills.mul"), root.resolve("Skills.idx"))
        ) {
            return new GameDataProviderImpl(mapReader, staticReader, tileData, skillsReader);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

}
